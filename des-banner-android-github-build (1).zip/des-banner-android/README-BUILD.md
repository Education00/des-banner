# Build APK bằng điện thoại

Project này đã thêm GitHub Actions để tự build file APK online.

## Cách làm trên điện thoại

1. Vào GitHub bằng tài khoản email: tt572880@gmail.com
2. Tạo repository mới, ví dụ: `des-banner-app`
3. Upload toàn bộ thư mục project này lên repository
4. Mở tab **Actions**
5. Chọn **Build APK**
6. Bấm **Run workflow**
7. Đợi chạy xong, mở workflow vừa chạy
8. Tải file ở mục **Artifacts**: `des-banner-debug-apk`
9. Giải nén artifact, cài file `.apk` trên điện thoại Android

## Ghi chú

- App chạy offline bằng Android WebView.
- File HTML/CSS/JS nằm trong: `app/src/main/assets/www/`
- APK debug dùng để chạy thử. Khi muốn phát hành chính thức cần build bản release và ký app.
