# Des Banner Studio V5.5 Pro

Bản V5.5:
- Thêm nhóm Unicode style:
  - 𝕷𝖔𝖗𝖊𝖒
  - ᴸᵒʳᵉᵐ
  - 𝕃𝕠𝕣𝕖𝕞
  - ʟᴏʀᴇᴍ
  - 𝙇𝙤𝙧𝙚𝙢
- Font popup hiển thị minh họa bằng chính chữ đang nhập.
- Thêm tên font UVF Slim Tony và VNF Sofia vào danh sách mẫu.
  Lưu ý: đây là tên preset/fallback trước; để dùng đúng font thật cần import file .ttf/.otf ở bản sau.
- Giữ Live Preview kéo được/phóng to từ V5.4.

## Chạy Termux

```bash
cd ~/storage/downloads
unzip des-banner-v55-pro.zip
cd des-banner-v55-pro
npx serve .
```

Mở:
```text
http://localhost:3000
```
