const $=id=>document.getElementById(id);
const canvas=$("canvas"),ctx=canvas.getContext("2d"),miniCanvas=$("miniCanvas"),miniCtx=miniCanvas.getContext("2d"),qrEditCanvas=$("qrEditCanvas"),qrEditCtx=qrEditCanvas.getContext("2d");

const FONTS=[
  {name:"Bubble Cute",cat:"cute",css:"Arial Rounded MT Bold"},
  {name:"Cute Candy",cat:"cute",css:"Comic Sans MS"},
  {name:"Big Impact",cat:"cute",css:"Impact"},
  {name:"Soft Round",cat:"cute",css:"Trebuchet MS"},
  {name:"Puffy",cat:"cute",css:"Arial Black"},
  {name:"Georgia",cat:"simple",css:"Georgia"},
  {name:"Arial",cat:"simple",css:"Arial"},
  {name:"Verdana",cat:"simple",css:"Verdana"},
  {name:"Trebuchet",cat:"simple",css:"Trebuchet MS"},
  {name:"Courier",cat:"simple",css:"Courier New"},
  {name:"Clean Sans",cat:"simple",css:"system-ui"},
  {name:"Serif Pro",cat:"simple",css:"Georgia"},
  {name:"Hand Cute",cat:"hand",css:"Comic Sans MS"},
  {name:"Pacifico Style",cat:"hand",css:"cursive"},
  {name:"Script",cat:"hand",css:"Brush Script MT"},
  {name:"Marker",cat:"hand",css:"Comic Sans MS"},
  {name:"Pixel",cat:"cute",css:"monospace"},
  {name:"Poster",cat:"cute",css:"Impact"}
];

const state={
  banner:null,bannerSrc:"./assets/how-to-pay.jpg",
  qrImg:null,qrCanvas:null,pick:null,drag:false,dragData:null,active:"qr",
  qr:{x:148,y:705,size:560,radius:18,border:8,borderColor:"#f45ca5",cutWhite:false,recolor:false,color:"#f45ca5",cropZoom:100,cropX:0,cropY:0,cropStyle:"square",safeShape:"circle",safeSize:25,safeX:0,safeY:0,showSafe:true},
  textStyle:{font:"Georgia",fontCss:"Georgia",color:"#f45ca5",stroke:true,strokeColor:"#fff",strokeWidth:10,shadow:false,shadowBlur:0},
  texts:[]
};

function tip(t){$("status").textContent=t;clearTimeout(window.tipTimer);window.tipTimer=setTimeout(()=>$("status").textContent="Sẵn sàng",1800)}
function img(src){return new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=src})}
function file(f){return new Promise(res=>{const r=new FileReader();r.onload=e=>res(e.target.result);r.readAsDataURL(f)})}
async function loadBanner(src){state.banner=await img(src);canvas.width=state.banner.naturalWidth;canvas.height=state.banner.naturalHeight;miniCanvas.width=canvas.width;miniCanvas.height=canvas.height;["qrX","textX"].forEach(id=>$(id).max=canvas.width);["qrY","textY"].forEach(id=>$(id).max=canvas.height);draw();tip("Đã tải banner")}
async function loadQR(src){state.qrImg=await img(src);state.qr.cropZoom=100;state.qr.cropX=0;state.qr.cropY=0;autoProcessQR();drawQrEditor();draw();tip("AI đã cắt sạch viền, chỉ giữ mã QR")}
function sourceQR(){if(!state.qrImg)return null;const c=document.createElement("canvas");c.width=state.qrImg.naturalWidth;c.height=state.qrImg.naturalHeight;c.getContext("2d").drawImage(state.qrImg,0,0);return c}
function autoTrim(c){
  const ctx2=c.getContext("2d"),img=ctx2.getImageData(0,0,c.width,c.height),d=img.data;
  let minX=c.width,minY=c.height,maxX=0,maxY=0,found=false;
  // Ưu tiên phát hiện pixel QR tối/đen để bỏ sạch viền trắng, nền và khung màu.
  for(let y=0;y<c.height;y++){
    for(let x=0;x<c.width;x++){
      const i=(y*c.width+x)*4,r=d[i],g=d[i+1],b=d[i+2],a=d[i+3];
      if(a<20) continue;
      const max=Math.max(r,g,b), min=Math.min(r,g,b), br=(r+g+b)/3;
      const isQRDark = br < 120 && (max-min) < 80;
      if(isQRDark){
        found=true;
        minX=Math.min(minX,x); minY=Math.min(minY,y);
        maxX=Math.max(maxX,x); maxY=Math.max(maxY,y);
      }
    }
  }
  // Nếu QR màu không có pixel đen rõ, fallback nhận diện vùng không trắng.
  if(!found){
    minX=c.width; minY=c.height; maxX=0; maxY=0;
    for(let y=0;y<c.height;y++){
      for(let x=0;x<c.width;x++){
        const i=(y*c.width+x)*4,r=d[i],g=d[i+1],b=d[i+2],a=d[i+3];
        if(a>20&&(r<245||g<245||b<245)){
          minX=Math.min(minX,x); minY=Math.min(minY,y);
          maxX=Math.max(maxX,x); maxY=Math.max(maxY,y);
        }
      }
    }
  }
  if(maxX<=minX||maxY<=minY)return c;
  // Thêm quiet-zone nhỏ để QR vẫn dễ quét nhưng không giữ viền/nền thừa.
  const w=maxX-minX+1,h=maxY-minY+1,pad=Math.max(6,Math.round(Math.max(w,h)*0.025));
  minX=Math.max(0,minX-pad); minY=Math.max(0,minY-pad);
  maxX=Math.min(c.width-1,maxX+pad); maxY=Math.min(c.height-1,maxY+pad);
  const size=Math.max(maxX-minX+1,maxY-minY+1);
  const o=document.createElement("canvas"); o.width=size; o.height=size;
  const ox=o.getContext("2d"); ox.fillStyle="#fff"; ox.fillRect(0,0,size,size);
  ox.drawImage(c,minX,minY,maxX-minX+1,maxY-minY+1,(size-(maxX-minX+1))/2,(size-(maxY-minY+1))/2,maxX-minX+1,maxY-minY+1);
  return o
}
function inSafe(x,y,w,h){const q=state.qr;if(q.safeShape==="none")return false;const cx=w/2+(q.safeX/100)*w,cy=h/2+(q.safeY/100)*h,s=(q.safeSize/100)*Math.min(w,h);if(q.safeShape==="circle")return Math.hypot(x-cx,y-cy)<s;if(q.safeShape==="square"||q.safeShape==="round")return Math.abs(x-cx)<s&&Math.abs(y-cy)<s;return false}
function recolorAndCut(c){const o=document.createElement("canvas");o.width=c.width;o.height=c.height;const ox=o.getContext("2d");ox.drawImage(c,0,0);const img=ox.getImageData(0,0,o.width,o.height),d=img.data,rgb=hex(state.qr.color);for(let y=0;y<o.height;y++)for(let x=0;x<o.width;x++){const i=(y*o.width+x)*4,r=d[i],g=d[i+1],b=d[i+2],a=d[i+3],br=(r+g+b)/3;if(a<10)continue;if(inSafe(x,y,o.width,o.height))continue;if(state.qr.cutWhite&&br>185){d[i+3]=0;continue}if(state.qr.recolor&&br<170){d[i]=rgb.r;d[i+1]=rgb.g;d[i+2]=rgb.b}}ox.putImageData(img,0,0);return o}
function autoProcessQR(){let c=sourceQR();if(!c){state.qrCanvas=null;return}c=autoTrim(c);state.qrCanvas=recolorAndCut(c)}
function manualProcessQR(){const src=sourceQR();if(!src)return;const o=document.createElement("canvas");o.width=600;o.height=600;const ox=o.getContext("2d");ox.fillStyle="#fff";ox.fillRect(0,0,600,600);const zoom=state.qr.cropZoom/100;const base=Math.min(600/src.width,600/src.height)*zoom;const w=src.width*base,h=src.height*base;ox.drawImage(src,(600-w)/2+state.qr.cropX,(600-h)/2+state.qr.cropY,w,h);state.qrCanvas=recolorAndCut(autoTrim(o));draw()}
function drawQrEditor(){qrEditCtx.clearRect(0,0,qrEditCanvas.width,qrEditCanvas.height);qrEditCtx.fillStyle="#fff";qrEditCtx.fillRect(0,0,qrEditCanvas.width,qrEditCanvas.height);if(!state.qrImg){qrEditCtx.fillStyle="#64748b";qrEditCtx.font="700 18px Arial";qrEditCtx.textAlign="center";qrEditCtx.fillText("Upload QR để chỉnh",240,180);return}const src=state.qrImg,zoom=state.qr.cropZoom/100,base=Math.min(260/src.naturalWidth,260/src.naturalHeight)*zoom,w=src.naturalWidth*base,h=src.naturalHeight*base;qrEditCtx.drawImage(src,240-w/2+state.qr.cropX,180-h/2+state.qr.cropY,w,h);qrEditCtx.strokeStyle="#f45ca5";qrEditCtx.lineWidth=4;qrEditCtx.setLineDash([12,8]);if(state.qr.cropStyle==="circle"){qrEditCtx.beginPath();qrEditCtx.arc(240,180,130,0,Math.PI*2);qrEditCtx.stroke()}else{roundRect(qrEditCtx,110,50,260,260,state.qr.cropStyle==="round"?30:0);qrEditCtx.stroke()}}
function draw(exporting=false){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  if(state.banner)ctx.drawImage(state.banner,0,0,canvas.width,canvas.height);
  drawQR(exporting);
  drawTexts();
  if(!exporting)drawActive();
  updateMiniPreview(exporting);
}
function updateMiniPreview(exporting=false){
  if(!miniCtx||!miniCanvas.width)return;
  miniCtx.clearRect(0,0,miniCanvas.width,miniCanvas.height);
  miniCtx.drawImage(canvas,0,0);
}
function drawQR(exporting){const q=state.qr,c=state.qrCanvas,b=q.border;ctx.save();if(b){ctx.fillStyle=q.borderColor;roundRect(ctx,q.x-b,q.y-b,q.size+b*2,q.size+b*2,q.radius+b);ctx.fill()}roundRect(ctx,q.x,q.y,q.size,q.size,q.radius);ctx.clip();if(!q.cutWhite){ctx.fillStyle="#fff";ctx.fillRect(q.x,q.y,q.size,q.size)}if(c){ctx.save();if(q.cropStyle==="circle"){ctx.beginPath();ctx.arc(q.x+q.size/2,q.y+q.size/2,q.size/2,0,Math.PI*2);ctx.clip()}ctx.drawImage(c,q.x,q.y,q.size,q.size);ctx.restore()}ctx.restore();if(!exporting&&q.showSafe&&state.qrCanvas)drawSafe()}
function drawSafe(){const q=state.qr,cx=q.x+q.size/2+(q.safeX/100)*q.size,cy=q.y+q.size/2+(q.safeY/100)*q.size,s=(q.safeSize/100)*q.size;ctx.save();ctx.strokeStyle="#00c853";ctx.lineWidth=4;ctx.setLineDash([10,8]);if(q.safeShape==="circle"){ctx.beginPath();ctx.arc(cx,cy,s,0,Math.PI*2);ctx.stroke()}else if(q.safeShape!=="none"){roundRect(ctx,cx-s,cy-s,s*2,s*2,q.safeShape==="round"?20:0);ctx.stroke()}ctx.restore()}
function drawTexts(){state.texts.forEach(t=>drawText(t))}
function drawText(t){const s=state.textStyle;ctx.save();ctx.font=`900 ${t.size}px ${fontStack(s.fontCss)}`;ctx.textAlign="center";ctx.textBaseline="middle";ctx.lineJoin="round";if(s.shadow){ctx.shadowColor=s.color;ctx.shadowBlur=s.shadowBlur;ctx.shadowOffsetX=2;ctx.shadowOffsetY=2}if(s.stroke&&s.strokeWidth){ctx.lineWidth=s.strokeWidth;ctx.strokeStyle=s.strokeColor;ctx.strokeText(t.value,t.x,t.y)}ctx.fillStyle=s.color;ctx.fillText(t.value,t.x,t.y);ctx.restore()}
function fontStack(f){return f.includes(" ") ? `"${f}", Arial` : f}
function selectedText(){return state.texts.find(t=>t.id===state.active)||state.texts[0]}
function drawActive(){ctx.save();ctx.strokeStyle="#007aff";ctx.lineWidth=5;ctx.setLineDash([14,10]);if(state.active==="qr"){const q=state.qr;ctx.strokeRect(q.x,q.y,q.size,q.size)}else{const t=selectedText();if(t){ctx.beginPath();ctx.arc(t.x,t.y,38,0,Math.PI*2);ctx.stroke()}}ctx.restore()}
function roundRect(c,x,y,w,h,r){r=Math.min(r,w/2,h/2);c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()}
function hex(h){h=h.replace("#","");return{r:parseInt(h.slice(0,2),16),g:parseInt(h.slice(2,4),16),b:parseInt(h.slice(4,6),16)}}

function syncControls(){const q=state.qr,s=state.textStyle,t=selectedText();$("qrSize").value=q.size;$("qrX").value=q.x;$("qrY").value=q.y;$("qrRadius").value=q.radius;$("qrBorder").value=q.border;$("qrBorderColor").value=q.borderColor;$("cutWhite").checked=q.cutWhite;$("recolor").checked=q.recolor;$("qrColor").value=q.color;$("cropZoom").value=q.cropZoom;$("safeShape").value=q.safeShape;$("safeSize").value=q.safeSize;$("safeX").value=q.safeX;$("safeY").value=q.safeY;$("showSafe").checked=q.showSafe;$("fontName").textContent=s.font;$("textColor").value=s.color;$("strokeOn").checked=s.stroke;$("strokeColor").value=s.strokeColor;$("strokeWidth").value=s.strokeWidth;$("shadowOn").checked=s.shadow;$("shadowBlur").value=s.shadowBlur;if(t){$("textValue").value=t.value;$("textSize").value=t.size;$("textX").value=t.x;$("textY").value=t.y}else{$("textValue").value="";$("textSize").value=58}$("emptyText").classList.toggle("hidden",state.texts.length>0);$("textTools").classList.toggle("hidden",state.texts.length===0);renderTexts();renderLayers();renderFonts();updateLabels();draw()}
function updateLabels(){const q=state.qr,s=state.textStyle,t=selectedText();$("qrSizeVal").textContent=q.size+"px";$("qrRadiusVal").textContent=q.radius+"px";$("qrBorderVal").textContent=q.border+"px";$("cropZoomVal").textContent=q.cropZoom+"%";$("safeSizeVal").textContent=q.safeSize+"%";$("safeXVal").textContent=q.safeX+"%";$("safeYVal").textContent=q.safeY+"%";$("textSizeVal").textContent=(t?t.size:0)+"px";$("strokeVal").textContent=s.strokeWidth+"px";$("shadowVal").textContent=s.shadowBlur+"px"}
function updateFromControls(){const q=state.qr,s=state.textStyle,t=selectedText();q.size=+$("qrSize").value;q.x=+$("qrX").value;q.y=+$("qrY").value;q.radius=+$("qrRadius").value;q.border=+$("qrBorder").value;q.borderColor=$("qrBorderColor").value;q.cutWhite=$("cutWhite").checked;q.recolor=$("recolor").checked;q.color=$("qrColor").value;q.cropZoom=+$("cropZoom").value;q.safeShape=$("safeShape").value;q.safeSize=+$("safeSize").value;q.safeX=+$("safeX").value;q.safeY=+$("safeY").value;q.showSafe=$("showSafe").checked;s.color=$("textColor").value;s.stroke=$("strokeOn").checked;s.strokeColor=$("strokeColor").value;s.strokeWidth=+$("strokeWidth").value;s.shadow=$("shadowOn").checked;s.shadowBlur=+$("shadowBlur").value;if(t){t.value=$("textValue").value;t.size=+$("textSize").value;t.x=+$("textX").value;t.y=+$("textY").value}autoProcessQR();drawQrEditor();syncControls()}
["qrSize","qrX","qrY","qrRadius","qrBorder","qrBorderColor","cutWhite","recolor","qrColor","cropZoom","safeShape","safeSize","safeX","safeY","showSafe","textValue","textSize","textX","textY","textColor","strokeOn","strokeColor","strokeWidth","shadowOn","shadowBlur"].forEach(id=>$(id).addEventListener("input",updateFromControls));

function renderTexts(){const box=$("textList");box.innerHTML="";state.texts.forEach((t,i)=>{const div=document.createElement("div");div.className="textItem "+(state.active===t.id?"active":"");div.innerHTML=`<button>${t.label}</button><input value="${t.value.replace(/"/g,'&quot;')}"><button>✕</button>`;div.children[0].onclick=()=>{state.active=t.id;syncControls()};div.children[1].oninput=e=>{t.value=e.target.value;draw()};div.children[2].onclick=()=>deleteText(t.id);box.appendChild(div)})}
function renderLayers(){const box=$("layerTabs");box.innerHTML=`<button class="${state.active==="qr"?"active":""}" data-layer="qr">QR</button>`+state.texts.map(t=>`<button class="${state.active===t.id?"active":""}" data-layer="${t.id}">${t.label}</button>`).join("");box.querySelectorAll("button").forEach(b=>b.onclick=()=>{state.active=b.dataset.layer;syncControls()})}
function addText(){const n=state.texts.length+1,id="text"+Date.now();state.texts.push({id,label:"Dòng "+n,value:"Nhập nội dung...",x:canvas.width*.65,y:canvas.height*.65+(n-1)*80,size:58});state.active=id;syncControls();tip("Đã thêm chữ")}
function deleteText(id=state.active){if(id==="qr")return alert("Hãy chọn chữ trước khi xóa.");state.texts=state.texts.filter(t=>t.id!==id);state.active=state.texts[0]?.id||"qr";syncControls();tip("Đã xóa chữ")}
$("firstAddText").onclick=addText;$("addTextBtn").onclick=addText;$("deleteTextBtn").onclick=()=>deleteText();

function renderFonts(){
  const search=($("fontSearch").value||"").toLowerCase();
  const cat=document.querySelector(".fontCats button.active")?.dataset.cat||"all";
  const list=$("fontList");
  const sample=(selectedText()?.value||"Hữu Anh").trim()||"Hữu Anh";
  list.innerHTML="";
  FONTS.filter(f=>(cat==="all"||f.cat===cat)&&f.name.toLowerCase().includes(search)).forEach(f=>{
    const row=document.createElement("button");
    row.className="fontRow "+(state.textStyle.font===f.name?"active":"");
    row.innerHTML=`<b style="font-family:${fontStack(f.css)}">${sample}</b><span>${f.name}</span>`;
    row.onclick=()=>{
      state.textStyle.font=f.name;
      state.textStyle.fontCss=f.css;
      closeFont();
      syncControls();
      tip("Đã chọn font "+f.name)
    };
    list.appendChild(row)
  })
}
function openFont(){renderFonts();$("fontModal").classList.add("open")}function closeFont(){$("fontModal").classList.remove("open")}
$("fontPicker").onclick=openFont;$("closeFont").onclick=closeFont;$("fontSearch").oninput=renderFonts;document.querySelectorAll(".fontCats button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".fontCats button").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderFonts()});
$("menuImportFont").onclick=()=>{closeDrawer();alert("Bản test V5: Import font sẽ thêm ở V5.1. Hiện dùng font có sẵn trước nhé.")};

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$("page-"+b.dataset.page).classList.add("active")});
document.querySelectorAll(".stepper button").forEach(b=>b.onclick=()=>{const el=$(b.dataset.target);el.value=+el.value+(+b.dataset.step);el.dispatchEvent(new Event("input"));tip("Đã chỉnh")});
document.querySelectorAll(".cropStyle").forEach(b=>b.onclick=()=>{document.querySelectorAll(".cropStyle").forEach(x=>x.classList.remove("active"));b.classList.add("active");state.qr.cropStyle=b.dataset.style;drawQrEditor();draw();tip("Đã chọn kiểu "+b.textContent)});
document.querySelectorAll("#qrPalette button").forEach(b=>b.onclick=()=>{$("qrColor").value=b.dataset.color;$("recolor").checked=true;updateFromControls()});
document.querySelectorAll("#textPalette button").forEach(b=>b.onclick=()=>{$("textColor").value=b.dataset.color;updateFromControls()});

$("qrUploadBtn").onclick=()=>$("qrFile").click();$("menuUploadQR").onclick=()=>{closeDrawer();$("qrFile").click()};$("qrFile").onchange=async e=>{if(e.target.files[0])await loadQR(await file(e.target.files[0]))};
$("bannerBtn").onclick=()=>$("bannerFile").click();$("menuUploadBanner").onclick=()=>{closeDrawer();$("bannerFile").click()};$("bannerFile").onchange=async e=>{if(e.target.files[0])await loadBanner(await file(e.target.files[0]))};
$("defaultBanner").onclick=()=>loadBanner("./assets/how-to-pay.jpg");$("menuDefault")?.addEventListener("click",()=>loadBanner("./assets/how-to-pay.jpg"));
$("autoApply").onclick=()=>{autoProcessQR();draw();tip("Đã dùng tự động")};$("openManual").onclick=()=>{$("manualBox").classList.remove("hidden");drawQrEditor();tip("Đã mở chỉnh thủ công")};$("resetManual").onclick=()=>{state.qr.cropZoom=100;state.qr.cropX=0;state.qr.cropY=0;syncControls();tip("Đã reset thủ công")};$("applyManual").onclick=()=>{manualProcessQR();tip("Đã áp dụng chỉnh thủ công")};

function p2c(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*(canvas.width/r.width),y:(e.clientY-r.top)*(canvas.height/r.height)}}
function pixel(x,y){const d=ctx.getImageData(Math.max(0,Math.floor(x)),Math.max(0,Math.floor(y)),1,1).data;return"#"+[d[0],d[1],d[2]].map(v=>v.toString(16).padStart(2,"0")).join("")}
$("pickQrColor").onclick=()=>{state.pick="qr";tip("Chạm banner để lấy màu QR")};$("pickTextColor").onclick=()=>{state.pick="text";tip("Chạm banner để lấy màu chữ")};
$("dragBtn").onclick=()=>{state.drag=!state.drag;$("dragBtn").textContent="Kéo: "+(state.drag?"Bật":"Tắt");$("canvasBox").classList.toggle("dragging",state.drag);tip(state.drag?"Đã bật kéo":"Đã tắt kéo")};
canvas.addEventListener("pointerdown",e=>{const p=p2c(e);if(state.pick){const c=pixel(p.x,p.y);if(state.pick==="qr"){$("qrColor").value=c;$("recolor").checked=true}else $("textColor").value=c;state.pick=null;updateFromControls();tip("Đã lấy màu "+c);return}if(!state.drag)return;e.preventDefault();canvas.setPointerCapture(e.pointerId);state.dragData={p,qr:{x:state.qr.x,y:state.qr.y},texts:state.texts.map(t=>({...t}))}},{passive:false});
canvas.addEventListener("pointermove",e=>{if(!state.dragData)return;e.preventDefault();const p=p2c(e),dx=p.x-state.dragData.p.x,dy=p.y-state.dragData.p.y;if(state.active==="qr"){state.qr.x=state.dragData.qr.x+dx;state.qr.y=state.dragData.qr.y+dy}else{const old=state.dragData.texts.find(t=>t.id===state.active),cur=selectedText();if(old&&cur){cur.x=old.x+dx;cur.y=old.y+dy}}syncControls()},{passive:false});
canvas.addEventListener("pointerup",()=>state.dragData=null);canvas.addEventListener("pointercancel",()=>state.dragData=null);

let editDrag=null;
function editPos(e){const r=qrEditCanvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
qrEditCanvas.addEventListener("pointerdown",e=>{if(!state.qrImg)return;const p=editPos(e);qrEditCanvas.setPointerCapture(e.pointerId);editDrag={p,x:state.qr.cropX,y:state.qr.cropY}});
qrEditCanvas.addEventListener("pointermove",e=>{if(!editDrag)return;const p=editPos(e);state.qr.cropX=editDrag.x+(p.x-editDrag.p.x);state.qr.cropY=editDrag.y+(p.y-editDrag.p.y);drawQrEditor()});
qrEditCanvas.addEventListener("pointerup",()=>editDrag=null);qrEditCanvas.addEventListener("pointercancel",()=>editDrag=null);

$("pasteBtn").onclick=()=>{const lines=$("pasteText").value.split("\n").map(x=>x.trim()).filter(Boolean);lines.forEach((v,i)=>{if(state.texts[i])state.texts[i].value=v;else state.texts.push({id:"text"+Date.now()+i,label:"Dòng "+(i+1),value:v,x:canvas.width*.65,y:canvas.height*.65+i*80,size:58})});state.active=state.texts[0]?.id||"qr";syncControls();tip("Đã tự điền")};
$("resetPos").onclick=()=>{state.qr.x=148;state.qr.y=705;state.qr.size=560;if(state.texts[0]){state.texts[0].x=920;state.texts[0].y=1068}if(state.texts[1]){state.texts[1].x=955;state.texts[1].y=1224}syncControls();tip("Đã reset vị trí")};

function saveHistory(){draw(true);const item={id:Date.now(),time:new Date().toLocaleString("vi-VN"),qr:state.qr,textStyle:state.textStyle,texts:state.texts,preview:canvas.toDataURL("image/jpeg",.65)};draw(false);const arr=JSON.parse(localStorage.getItem("des_v54_history")||"[]");arr.unshift(item);localStorage.setItem("des_v54_history",JSON.stringify(arr.slice(0,30)));tip("Đã lưu vào lịch sử")}
function openHistory(){renderHistory();$("historyModal").classList.add("open")}function closeHistory(){$("historyModal").classList.remove("open")}
function renderHistory(){const arr=JSON.parse(localStorage.getItem("des_v54_history")||"[]");const box=$("historyList");box.innerHTML=arr.length?"":"<p>Chưa có lịch sử.</p>";arr.forEach(it=>{const d=document.createElement("div");d.className="hist";d.innerHTML=`<img src="${it.preview}"><div><b>${it.time}</b><div class="histBtns"><button data-open="${it.id}">Mở</button><button data-copy="${it.id}">Nhân bản</button><button data-del="${it.id}" class="danger">Xóa</button></div></div>`;box.appendChild(d)});box.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>loadHist(+b.dataset.open));box.querySelectorAll("[data-copy]").forEach(b=>b.onclick=()=>{loadHist(+b.dataset.copy);saveHistory()});box.querySelectorAll("[data-del]").forEach(b=>b.onclick=()=>{let a=JSON.parse(localStorage.getItem("des_v54_history")||"[]").filter(x=>x.id!=b.dataset.del);localStorage.setItem("des_v54_history",JSON.stringify(a));renderHistory()})}
function loadHist(id){const arr=JSON.parse(localStorage.getItem("des_v54_history")||"[]");const it=arr.find(x=>x.id===id);if(!it)return;state.qr={...state.qr,...it.qr};state.textStyle={...state.textStyle,...it.textStyle};state.texts=it.texts||[];state.active=state.texts[0]?.id||"qr";closeHistory();syncControls();tip("Đã mở lịch sử")}
$("saveBtn").onclick=saveHistory;$("saveBtn2").onclick=saveHistory;$("historyBtn").onclick=openHistory;$("openHistory2").onclick=openHistory;$("closeHistory").onclick=closeHistory;$("menuHistory").onclick=()=>{closeDrawer();openHistory()};$("menuSave").onclick=()=>{closeDrawer();saveHistory()};

function exportPNG(){draw(true);const s=+$("exportScale").value||1;const out=document.createElement("canvas");out.width=canvas.width*s;out.height=canvas.height*s;const ox=out.getContext("2d");ox.scale(s,s);ox.drawImage(canvas,0,0);const a=document.createElement("a");a.download="des-banner-v54.png";a.href=out.toDataURL("image/png");a.click();draw(false);tip("Đã xuất PNG")}
$("exportBtn").onclick=exportPNG;$("menuExport").onclick=()=>{closeDrawer();exportPNG()};

function openDrawer(){$("drawer").classList.add("open");$("drawerShade").classList.add("open")}function closeDrawer(){$("drawer").classList.remove("open");$("drawerShade").classList.remove("open")}
$("menuBtn").onclick=openDrawer;$("closeDrawer").onclick=closeDrawer;$("drawerShade").onclick=closeDrawer;$("menuReset").onclick=()=>{if(confirm("Reset toàn bộ?")){state.texts=[];state.active="qr";syncControls();closeDrawer();tip("Đã reset")}};


// Floating live preview controls
let floatDrag=null;
function clampFloat(){
  const el=$("floatPreview");
  const r=el.getBoundingClientRect();
  let left=r.left, top=r.top;
  left=Math.max(8,Math.min(window.innerWidth-r.width-8,left));
  top=Math.max(8,Math.min(window.innerHeight-r.height-8,top));
  el.style.left=left+"px";
  el.style.top=top+"px";
  el.style.right="auto";
  el.style.bottom="auto";
}
$("floatClose").onclick=()=>{
  $("floatPreview").classList.add("hidden");
  $("showFloat").classList.add("show");
};
$("showFloat").onclick=()=>{
  $("floatPreview").classList.remove("hidden");
  $("showFloat").classList.remove("show");
};
$("floatSmall").onclick=()=>{
  const el=$("floatPreview");
  el.classList.toggle("small");
  if(el.classList.contains("small")){
    el.classList.remove("medium","large");
    $("floatSmall").textContent="+";
  }else{
    $("floatSmall").textContent="−";
  }
  setTimeout(clampFloat,0);
};
$("floatGrow").onclick=()=>{
  const el=$("floatPreview");
  el.classList.remove("small");
  $("floatSmall").textContent="−";
  if(el.classList.contains("large")){
    el.classList.remove("large");
    el.classList.add("medium");
  }else if(el.classList.contains("medium")){
    el.classList.remove("medium");
    el.classList.add("large");
  }else{
    el.classList.add("medium");
  }
  setTimeout(clampFloat,0);
};
$("floatPreview").querySelector(".floatHead").addEventListener("pointerdown",e=>{
  if(e.target.tagName==="BUTTON")return;
  const el=$("floatPreview"),r=el.getBoundingClientRect();
  floatDrag={dx:e.clientX-r.left,dy:e.clientY-r.top};
  el.setPointerCapture?.(e.pointerId);
});
window.addEventListener("pointermove",e=>{
  if(!floatDrag)return;
  const el=$("floatPreview");
  el.style.left=(e.clientX-floatDrag.dx)+"px";
  el.style.top=(e.clientY-floatDrag.dy)+"px";
  el.style.right="auto";
  el.style.bottom="auto";
  clampFloat();
});
window.addEventListener("pointerup",()=>floatDrag=null);
window.addEventListener("resize",clampFloat);

loadBanner(state.bannerSrc);syncControls();renderFonts();drawQrEditor();
